"use strict";

//////////////////// TODOS CONTROLLER /////////////////////

const todosController = (() => {
    // Class definition for Todo object
    class Todo {
        constructor(id, done, label, order) {
            this.id = id;
            this.done = done;
            this.label = label;
            this.order = order;
        }
    }
    // Universal data container object
    let data = {
        todos: []
    };

    // Find index of Todo id in data helper function
    const findIndexOfId = (id) => data.todos.findIndex(item => item.id === parseInt(id));
    
    // Local Storage save helper function
    const saveDataToLocalStorage = () => {
        localStorage.setItem("todos", JSON.stringify(data.todos));
    };
    
    return {
        addTodo: (label) => {
            let id, order, newItem;
            // All new items are not done yet
            const done = false;
            // Set id to one more than highest number available in data array
            if (data.todos.length > 0) {
                let idArray = [];
                data.todos.map(todo => idArray.push(todo.id));
                const maxId = idArray.reduce((a, b) => Math.max(a, b));
                id = maxId + 1;
            } else {
                id = 0;
            }
            // Set order to one more than highest number available in data array
            if (data.todos.length > 0) {
                order = data.todos.length;
            } else {
                order = 0;
            }
            // create new Todo object
            newItem = new Todo(id, done, label, order);
            // Save new Todo to data array
            data.todos.push(newItem);
            // Save data array to local storage
            saveDataToLocalStorage();
            // Return new Todo for additional Controller actions
            return newItem;
        },
        changeTodoOrder: function(id, order) {
            const indexOfId = findIndexOfId(id);
            data.todos[indexOfId].order = parseInt(order);
            // Save data array to local storage
            saveDataToLocalStorage();
        },
        changeTodoStatus: (id) => {
            const indexOfId = findIndexOfId(id);
            data.todos[indexOfId].done === false ? data.todos[indexOfId].done = true : data.todos[indexOfId].done = false;
            // Save data array to local storage
            saveDataToLocalStorage();
        },
        removeTodo: (id) => {
            const indexOfId = findIndexOfId(id);
            data.todos.splice(indexOfId, 1);
            // Rewrite order to prevent gaps
            let currentOrder = [];
            data.todos.map(item => currentOrder.push([item.id, item.order]));
            const newOrder = currentOrder.sort((a, b) => a[1] - b[1]);
            let orderIterator = 0;
            newOrder.forEach(item => {
                const id = item[0];
                const indexOfId = findIndexOfId(id);
                data.todos[indexOfId].order = orderIterator;
                orderIterator++
            });
            // Save data array to local storage
            saveDataToLocalStorage();
        },
        getDataTEST: () => {
            console.log(data);
        },
        getTodoData: () => {
            return data.todos;
        },
        getTodoCount: () => {
            return data.todos.length;
        },
        setTodoData: (importedData) => {
            data.todos = importedData;
        }
    }

})();





////////////////////// UI CONTROLLER //////////////////////

const uiController = (() => {
    // Globally available list of UI element selectors
    const domElements = {
        searchField: ".search",
        todoAddButton: ".header__add-button",
        todoContainer: ".todos",
        todoDelete: ".todo__delete-icon",
        todoDeleteUse: ".todo__delete-use",
        todoEmpty: ".todos__empty",
        todoInput: ".header__add-input",
        todoStatus: ".todo__status"
    };
    
    return {
        // Add Todo item to list view
        addTodoItem: function(item, searchString) {
            // Hide empty state, if necessary
            document.querySelector(domElements.todoEmpty).style.display = "none";
            let label;
            // Check if search is performed, and add highlight span to label accordingly
            if (searchString === undefined || searchString === "") {
                label = item.label;
            } else {
                const regEx = new RegExp(searchString, "ig");
                const explodedLabel = item.label.replace(regEx, '<span class="highlight">$&</span>');
                label = explodedLabel;
            }
            // Todo item template
            const itemHtml = `
                <article class="todo${item.done === true ? ` done` : ``}" id="${item.id}">
					<div class="todo__check">
						<input id="${item.id}-status" type="checkbox" class="todo__status" ${item.done === true ? `checked` : ``}>
						<label for="${item.id}-status">
							<svg class="todo__status-icon">
                                ${item.done === true ? `<use href="img/sprite.svg#icon-ios-checkmark-circle">` : `<use href="img/sprite.svg#icon-ios-radio-button-off">`}>								
							</svg>
						</label>						
					</div>
                    <div class="todo__label">${label}</div>
					<div class="todo__actions">
                        <svg class="todo__delete-icon">
							<use href="img/sprite.svg#icon-ios-close-circle-outline" class="todo__delete-use">
						</svg>
                    </div>
				</article>`;
            // Insert Todo item at the top of the container
            const todoContainer = document.querySelector(domElements.todoContainer);
            todoContainer.insertAdjacentHTML('afterbegin', itemHtml);
        },
        // Change Todo status when an item is clicked
        changeTodoItemStatus: (element) => {          
            // Get checkbox status
            const checkedStatus = element.checked;
            // Update icon and item style accordingly
            const toggleElement = (href) => {
                element.nextElementSibling.childNodes[1].childNodes[1].setAttribute("href", href);
                element.parentNode.parentNode.classList.toggle("done");
            }
            if (checkedStatus) {
                toggleElement("img/sprite.svg#icon-ios-checkmark-circle");
            } else {
                toggleElement("img/sprite.svg#icon-ios-radio-button-off");
            }
        },
        // Filter entries based on search string (evaluate lowercase)
        filterEntries: function(event) {
            const searchString = event.target.value;
            const searchStringLowercase = searchString.toLowerCase();
            const allEntries = todosController.getTodoData();
            const filteredEntries = allEntries.filter(entry => {
                const entryLowercase = entry.label.toLowerCase();
                return entryLowercase.includes(searchStringLowercase);
            });
            // Clear currently displayed items first
            document.querySelectorAll(domElements.todoContainer + " article").forEach(item => item.parentNode.removeChild(item));
            // Rerender Todos list based on filter result
            filteredEntries.forEach(entry => uiController.addTodoItem(entry, searchString));
        },
        // Return DOM elements to Global Controller
        getDomElements: () => {
            return domElements;
        },
        // Return value of input field for Todo description
        getInputValue: () => {
            const todoInput = document.querySelector(domElements.todoInput);
            return todoInput.value;
        },
        // Control Todo sortability
        makeSortable: () => {
            const reorderTodos = new Sortable(document.querySelector(domElements.todoContainer), {
                // Rewrite data according to new order in UI when Todo is dropped
                onEnd: function() {
                    // Order is from bottom to top (as are IDs) which is why we reverse
                    const currentTodoOrder = Array.from(document.querySelectorAll(domElements.todoContainer + " article")).reverse();
                    let currentOrder = 0;
                    currentTodoOrder.forEach(todo => {
                        const currentId = todo.getAttribute("id");
                        // Remove inline style tag to get rid of a neutralized transform which messes with z-index
                        todo.removeAttribute("style");
                        // Tell Todo Controller to update data
                        todosController.changeTodoOrder(currentId, currentOrder);
                        currentOrder++;
                    });
                }
            });
        },
        // Remove Todo element from UI based on passed ID
        removeTodoItem: (id) => {
            const toDelete = document.getElementById(id);
            toDelete.parentNode.removeChild(toDelete);
            // If no todos are left, display empty state
            const todoCount = todosController.getTodoCount();
            if (todoCount === 0) {
                document.querySelector(domElements.todoEmpty).style.display = "block";
            }
        },
        // Reset input and button (when item is being created)
        resetInput: () => {
            document.querySelector(domElements.todoInput).value = "";
            document.querySelector(domElements.todoAddButton).setAttribute("disabled", true);
            document.querySelector(domElements.todoInput).focus();
        },
        // Populate Todos list with items from local storage
        setTodoItemData: function() {
            const data = todosController.getTodoData();
            data.sort((a, b) => a.order - b.order);
            data.forEach(item => this.addTodoItem(item));
        },
        // Enable add button while text is present in input field
        toggleAddButton: (event) => {
            const todoAddButton = document.querySelector(domElements.todoAddButton);
            if (event.target.value.length > 0) {
                todoAddButton.removeAttribute("disabled");
            } else {
                todoAddButton.setAttribute("disabled", true);
            }
        }
    }

})();





//////////////////// GLOBAL CONTROLLER ////////////////////

const controller = ((uiC, todosC) => {

    // Make DOM elements available here
    const domElements = uiC.getDomElements();
    
    // Control what gets done when a Todo is added
    const ctrlAddTodo = () => {
        // Get Todo description from UI Controller
        const inputValue = uiC.getInputValue();

        if (inputValue !== "") {
            // Create new Todo object
            const newItem = todosC.addTodo(inputValue);
            // Display new Todo in UI
            uiC.addTodoItem(newItem);
            // Reset input
            uiC.resetInput();
        }
    };
    
    // Control interactions with a Todo item
    const ctrlTodoInteractions = (event) => {
        // Extract target class for easy matching
        const targetClasses = Array.from(event.target.classList);

        // Handle Todo deletion
        const deleteClass = domElements.todoDelete.substr(1); // Strip "." from class name
        const deleteClassUse = domElements.todoDeleteUse.substr(1);
        // Twilight zone: handle two different event targets depending on what is sent
        if (targetClasses.includes(deleteClass)) {
            const id = event.target.parentNode.parentNode.id;
            removeTodo(id);
        }    
        if (targetClasses.includes(deleteClassUse)) {
            const id = event.target.parentNode.parentNode.parentNode.id;
            removeTodo(id);
        }        
        function removeTodo(id) {
            // Delete item from data
            todosC.removeTodo(id);
            // Remove item from UI
            uiC.removeTodoItem(id);
        }
        
        // Handle Todo status switch
        const statusClass = domElements.todoStatus.substr(1); // Strip "." from class name
        
        if (targetClasses.includes(statusClass)) {
            const id = event.target.parentNode.parentNode.id;
            const element = event.target;
            // Update status in data
            todosC.changeTodoStatus(id);
            // Update status in UI
            uiC.changeTodoItemStatus(element);
        }
    };
    
    const initializeLocalStorage = () => {
        if(!(localStorage.getItem("todos"))) {
            populateStorage();
        } else {
            importData();
        }
        function populateStorage() {
            localStorage.setItem("todos", JSON.stringify(todosC.getTodoData()));
        }
        function importData() {
            const importedData = JSON.parse(localStorage.getItem("todos"));
            // Send persistent data to Todos controller
            todosC.setTodoData(importedData);
            // Update UI with imported data
            uiC.setTodoItemData();
        }
    };
    
    const setupEventListeners = () => {        
        // Add event listener to input field
        document.querySelector(domElements.todoInput).addEventListener("keyup", (event) => {
            // If user hits enter, add Todo
            if (event.keyCode === 13) {
                ctrlAddTodo();
            // Otherwise, enable/disable add button
            } else {
                uiC.toggleAddButton(event);
            }
        });

        // Add event listener to add button
        document.querySelector(domElements.todoAddButton).addEventListener("click", ctrlAddTodo);

        // Add event listener to Todos container for item interaction
        document.querySelector(domElements.todoContainer).addEventListener("click", ctrlTodoInteractions);
        
        // Add event listener to search field
        document.querySelector(domElements.searchField).addEventListener("input", uiC.filterEntries);
    };
    
    return {
        init: () => {
            setupEventListeners();
            initializeLocalStorage();
            uiC.makeSortable();
        }
    };
    
})(uiController, todosController);

controller.init();