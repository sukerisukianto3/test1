function setContentBody(ele) {

    var content = document.getElementById("contentBody");
    if (content.childElementCount > 0) {
        content.removeChild(content.childNodes[0]);
    }
    content.appendChild(ele);
}

function setContentBodyJQ(ele) {

    var content = $("#contentBody");
    content.empty();

    content.append(ele);
}

function setContentFooter(ele) {

    var content = document.getElementById("contentFooter");
    if (content.childElementCount > 0) {
        content.removeChild(content.childNodes[0]);
    }
    content.appendChild(ele);
}


function createTableBody(id, cls = "") {
    var tbody = document.createElement("tbody");
    tbody.setAttribute("id", id);
    if (cls != "") {
        tbody.setAttribute("class", cls);
    }
    return tbody;
}

function createTHTag(txt, colsp, cls = "") {
    var th = document.createElement("th");
    var text = document.createTextNode(txt);
    th.appendChild(text);
    th.setAttribute("colspan", colsp);
    if (cls != "") {
        th.setAttribute("class", cls);
    }
    return th;
}

function createTDText(txt, cls = "") {
    var td = document.createElement("td");
    var text = document.createTextNode(txt);
    td.appendChild(text);
    if (cls != "") {
        td.setAttribute("class", cls);
    }
    return td;
}

function createTDTag(tag, id, val, cls = "") {
    var inp, td;
    inp = document.createElement(tag);
    inp.setAttribute("id", id);
    inp.setAttribute("value", val);
    td = document.createElement("td");
    if (cls != "") {
        td.setAttribute("class", cls);
    }
    td.appendChild(inp);
    return td;
}
function createTDButton(id, titel, act) {

    td = document.createElement("td");
    td.appendChild(createButton(id, titel, act));
    return td;
}
function createButton(id, titel, act) {
    var btn, td, text;
    btn = document.createElement("button");
    btn.setAttribute("id", id);
    btn.setAttribute("onclick", act);
    text = document.createTextNode(titel);
    btn.appendChild(text);
    return btn;
}

function searchInTableTR($par1, $par2) {
    //$par1 = "#myInput"
    //TR ="#myTable tr"
    $(document).ready(function () {
        $par1.on("keyup", function () {
            var value = $(this).val().toLowerCase();
            $par2.filter(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });

}

function contentEmpty() {
    $("#contentHeader").empty();
    $("#contentBody").empty();
    $("#contentFooter").empty();
}

/**
 * 
 * @param {object} injson --  object to be transfered
 * @param {String} filename -- name of the file where object will be stored
 */
function transferToServer(injson, filename) {
    // Object -> JSON (string)
    var objectsStr = JSON.stringify(injson);
    var request = new XMLHttpRequest();

    request.open("POST", "php/save.php?file=" + filename, true);
    request.setRequestHeader("Content-type", "application/json");
    request.send(objectsStr);
}
/**
 * prepare the all needed data
 * display menus in navigation 
 */

function loadAllData() {
    /*loadMenu();
    loadBooksData();
    loadDataCustomer();
    loadBilling(); */
    loadData(1,"data/menu.txt"); //menu and display them
    loadData(2,"data/book_catalog.txt"); //book
    loadData(3,"data/customer.txt"); //customer
    loadData(4,"data/billing.txt"); // billing 
}
/**
 * 
 * @param {Date} inDate -- date to be converted
 * result : dd.mm.yyyy
 */

function parseDateToText(inDate) {
    var txt = "";
    txt = (inDate.getDate() < 10 ? "0" : "") + inDate.getDate() + "." + (inDate.getMonth() < 9 ? "0" : "") + (inDate.getMonth() + 1) + "." + inDate.getFullYear();
    return txt;
}
/**
 * 
 * @param {number} objId - which object is needed
 * @param {String} fileName -- location of the file for this objects
 */
function loadData(objId, fileName) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            switch (objId) {
                case 1: { // menu
                    parseToObjectsMenu(this);
                    break;
                }
                case 2: { //book
                    parseToObjectsBook(this);
                    break;
                }
                case 3: { //Customer
                    parseToObjectsCustomer(this);
                    break;
                }
                case 4: { //Billing
                    parseToObjectsBilling(this);
                    break;
                }
                default: {
                    break;
                }
            }
          
        }
    };
    xhttp.open("GET", fileName, true);
    xhttp.send();
}
