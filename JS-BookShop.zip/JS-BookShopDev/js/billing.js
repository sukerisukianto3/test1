"use strict";

var billings = [];
var currbilling;
const MWST = 0.19;

function invoice(cust = "", addr = [], lines = []) {
    var custname, address, lines,date;

    this.custname = cust;
    this.address = addr;
    this.lines = lines;
    this.date = new Date();

}

function invoiceline(title = "", qty = 1, price = 0.0) {

    var title, qty, price;

    this.title = title;
    this.qty = qty;
    this.price = price;

}

/*function loadBilling() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            parseToObjectsBilling(this);
        }
    };
    xhttp.open("GET", "data/billing.txt", true);
    xhttp.send();
}*/

function parseToObjectsBilling(json) {

    var jsonTxt = json.responseText;

    billings = JSON.parse(jsonTxt);

    // convert the date
    for (let key in billings) {
        billings[key].date=new Date(billings[key].date);
    }
}

function billingIt() {
    displayInvoice();
}

function displayInvoice() {

    var para, label, idx, opt, currCustName, iaddress;

    contentEmpty();

    var placeHolder = $("<p></p>");
    placeHolder.attr("id", "invdisplay");
    var header = $("<h2></h2>");
    header.text("Rechnung");
    placeHolder.append(header);

    para = $("<p></p>");
    label = $("<label></label>");
    label.text("Kunde");
    para.append(label);

    var inp = $("<input></input>");
    inp.attr("id", "customer");
    inp.attr("value", "");
    //get Customer
    inp.attr("onchange", "csShowCustomerAddress(this.value)");
    inp.attr("list", "customer_list");
    var datalist = $("<datalist></datalist>");
    datalist.attr("id", "customer_list");
    for (idx = 0; idx < customers.length; idx++) {
        opt = $('<option></option>');
        opt.text(customers[idx].name);
        datalist.append(opt);
    }
    para.append(inp);
    para.append(datalist);
    placeHolder.append(para);

    //for address
    para = $("<p></p>");
    para.attr("id", "iaddress");
    placeHolder.append(para);

    //display the date
    para = $("<p></p>");
    para.attr("id","rechdatum");
    var currDate = new Date();
    para.text("Datum:"+parseDateToText(currDate));

    placeHolder.append(para);

    //list item
    displayLine(placeHolder);



    setContentBodyJQ(placeHolder);

    //Button Kaufen
    var kaufenBtn = createButton("kaufen", "Kaufen", "billBuyIt()");
    kaufenBtn.setAttribute('disabled', true);
    setContentFooter(kaufenBtn);

}

function displayLine(placeHolder) {
    var tr, td, totalSum = 0, mwstValue = 0;
    var para = $("<p></p>");
    para.attr("id", "invinline");
    //table create
    var table = $("<table></table>");
    table.attr("class", "invtable");

    for (let key in carts) {
        tr = $("<tr></tr>");
        tr.attr("class","underline");
        td = $("<td></td>");
        td.append(carts[key].title);
        tr.append(td);
        td = $("<td></td>");
        td.append(carts[key].quantity);
        tr.append(td);
        td = $("<td></td>");
        td.append(carts[key].totalPrice());
        tr.append(td);
        table.append(tr);
        totalSum += carts[key].totalPrice();

    }

    //MWST
    tr = $("<tr></tr>");
    tr.attr("class", "spaceTop");
    tr.append($("<td></td>"));
    td = $("<td></td>");
    td.append("MwsT: " + (MWST * 100) + " %");
    tr.append(td);

    mwstValue = MWST * totalSum;
    td = $("<td></td>");
    td.append(mwstValue.toFixed(2));
    tr.append(td);
    table.append(tr);

    //total Sum
    tr = $("<tr></tr>");
    tr.attr("class", "spaceTop");
    tr.append($("<td></td>"));
    td = $("<td></td>");
    td.append("Total");
    tr.append(td);

    td = $("<td></td>");
    td.append((totalSum + mwstValue).toFixed(2)+" &euro;");
    tr.append(td);
    table.append(tr);

    para.append(table);


    placeHolder.append(para);
}

function billBuyIt() {
    //
    var cust = $("#customer");
    var custName = cust.val();
    var currCustomer = getAcustomer(custName);
    var currInvoice, currOrderline, orders = [];
    if (currCustomer != null) {
        for (let key in carts) {
            currOrderline = new invoiceline(carts[key].title, carts[key].quantity, carts[key].totalPrice());
            orders.push(currOrderline);
        }
        currInvoice = new invoice(currCustomer.name, currCustomer.address, orders);
        billings.push(currInvoice);
        transferToServer(billings,"../data/billing.txt");
    }

    var btnbKaufen = $("#kaufen");
    btnbKaufen.prop("disabled",true);
    shopingCartEmpty();
    
}

function listBilling() {

    var currBill,td;
    var text,price,totalPrice;

    contentEmpty();

    
    //Header
    var table =$("<table></table>");
    table.attr("id","listBilling");
    table.attr("class","tablesc");
    var tr =$("<tr></tr>");
    var th = $("<th></th>");
    th.text("Datum");
    th.attr("class","thsc");
    tr.append(th);

    th = $("<th></th>");
    th.text("Kunde");
    th.attr("class","thsc");
    tr.append(th);

    th = $("<th></th>");
    th.text("Position");
    th.attr("class","thsc");
    tr.append(th);

    th = $("<th></th>");
    th.text("Preis(\u20AC)");
    th.attr("class","thsc");
    tr.append(th);
    table.append(tr);

    //contents
    for(let key in billings) {
        currBill=billings[key];
        var tr =$("<tr></tr>");
        tr.attr("class","trsc");
        //datum
        td=$("<td></td>");
        td.attr("class","tdsc");
        td.text(parseDateToText(currBill.date));
        tr.append(td);
        //kunde
        td=$("<td></td>");
        td.attr("class","tdsc");
        td.append(currBill.custname+"<br>");
        td.append(currBill.address[0].street+"<br>");
        td.append(currBill.address[0].zipcode+"<br>");
        tr.append(td);
        //Position -- lines
        td=$("<td></td>");
        td.attr("class","tdsc");
        price=0;
        totalPrice=0;
        text="";
        for (let key2 in currBill.lines) {
            text += currBill.lines[key2].qty+" X ";
            text += currBill.lines[key2].title+"</br>";
            
            price +=currBill.lines[key2].price;
        }
        td.html(text);
        tr.append(td);
        //Price
        td=$("<td></td>");
        td.attr("class","tdsc");
        totalPrice = price + (price*MWST);
        td.text(totalPrice.toFixed(2));
        tr.append(td);

        table.append(tr);
    }

    setContentBodyJQ(table);
}
