"use strict";

var currTable;
var carts = [];

function cart(title, price = 1, quantity = 1) {

	var title;
	var quantity;
	var price;
	var totalPrice;

	this.title = title;
	this.quantity = quantity;
	this.price = price;
	this.totalPrice = () => { return this.quantity * + this.price; }

}
function toShopingCart(title, price, quantity) {
	carts.push(new cart(title, price, quantity));
	updateShopingCartEle();
}

function updateShopingCartEle() {
	//display numbers of carts
	var curNode = $("#scQtyTotal");
	curNode.text(carts.length + " Element(e)");
}

function showShopingCart() {

	var zurKasseBtn;


	contentEmpty();

	currTable = document.createElement("table");
	currTable.setAttribute("class", "tablesc");

	//header
	currTable.appendChild(createTHTag("Titel", 1, "thsc"));
	currTable.appendChild(createTHTag("Anzahl", 1, "thsc"));
	currTable.appendChild(createTHTag("Preis(\u20AC)", 1, "thsc"));
	currTable.appendChild(createTHTag("    ", 1, "thsc"));

	carts.forEach(createEleDetail);

	//display carts
	setContentBody(currTable);
	//Button zur Kasse
	zurKasseBtn = createButton("kasse", "zur Kasse", "billingIt()");
	setContentFooter(zurKasseBtn);

}

function createEleDetail(cart, index, array) {
	var tr, td, inp, img, txt;
	tr = document.createElement("tr");
	tr.setAttribute("class", "trsc");
	tr.appendChild(createTDText(cart.title, "tdsc"));
	//quantity
	inp = document.createElement("input");
	inp.setAttribute("id", "scquantity");
	inp.setAttribute("value", cart.quantity);
	inp.setAttribute("onchange", "scCalculatePrice(this.value" + "," + index + ")");
	td = document.createElement("td");
	td.setAttribute("class", "tdsc");
	td.appendChild(inp);
	tr.appendChild(td);
	tr.appendChild(createTDText(cart.totalPrice(), "tdsc"));
	//action
	td = createTDText("", "tdsc");
	img = document.createElement("img");
	img.setAttribute("src", "img/delete.png");
	img.setAttribute("alt", "delete");
	img.setAttribute("title", "l\u020Dschen dies Element");
	img.setAttribute("width", "25");
	img.setAttribute("height", "25");
	txt = "deleteShopingCart(" + index + ")";
	img.setAttribute("onclick", txt);
	td.appendChild(img);
	tr.appendChild(td);
	currTable.appendChild(tr);


}

function scCalculatePrice(qty, idx) {
	carts[idx].quantity = qty;
	showShopingCart();
}


function deleteShopingCart(currIdx) {

	carts.splice(currIdx, 1);
	//refresh display
	showShopingCart();
	updateShopingCartEle();
}
function shopingCartEmpty() {
	carts=[];
	updateShopingCartEle();
}
