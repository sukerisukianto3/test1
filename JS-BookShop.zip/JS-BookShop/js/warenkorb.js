function showWarenKorb() {
    alert("warenkorb");
}