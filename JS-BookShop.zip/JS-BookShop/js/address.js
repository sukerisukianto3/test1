"use strict";

function address(street="",zipcode="") {
    var street, zipcode;


    this.street = street;
    this.zipcode = zipcode;
}