"use strict";

var menus = [];
const btnu = "btnu";
const btnd = "btnd";
const mnu = "mn";



/*function loadMenu() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            parseToObjectsMenu(this);
        }
    };
    xhttp.open("GET", "data/menu.txt", true);
    xhttp.send();
}*/
function parseToObjectsMenu(json) {

    var jsonTxt = json.responseText;

	menus = JSON.parse(jsonTxt);
	displayAllMenus();
}

function menu(titel = "Default", sort = 0, children = [], action = "") {

	var titel, sort, children, action;

	this.title = titel;
	this.sort = sort;
	this.children = children;
	this.action = action;

}

function displayAllMenus() {
	var nav = document.getElementById("navigation");
	var uliste;
	var head;
	var id = 0;
	var text = "";
	var children;
	var btn;
	var img;
	var btntx1, btntx2;

	for (id = 0; id < menus.length; id++) {
		text = document.createTextNode(menus[id].title);
		head = document.createElement("h3");
		head.appendChild(text);
		nav.appendChild(head);
		uliste = document.createElement("ul");
		uliste.setAttribute("id", "ul" + id);
		//===============================
		img = document.createElement("img");
		img.setAttribute("src", "img/up-arrow1.png");
		btn = document.createElement("button");
		btntx1 = btnu + (id + 1);
		btn.setAttribute("id", btntx1);
		btn.appendChild(img);
		uliste.appendChild(btn);
		//===============================
		img = document.createElement("img");
		img.setAttribute("src", "img/down-arrow1.png");
		btn = document.createElement("button");
		btntx2 = btnd + (id + 1);
		btn.setAttribute("id", btntx2);
		btn.setAttribute("hidden", "hidden");
		btn.appendChild(img);
		uliste.append(btn);

		//===============================
		displayMenu(menus[id].children, uliste, id);
		nav.appendChild(uliste);
		//===============================
		//add function up and down
		menuUp($("#" + btntx1), $("#" + btntx2), $("." + mnu + id));
		menuDown($("#" + btntx2), $("#" + btntx1), $("." + mnu + id));
		//=======================

	}


}

function displayMenu(menus, uliste, idx) {

	var id;
	var liele;
	var text;
	
	for (id = 0; id < menus.length; id++) {
		liele = document.createElement("li");
		liele.setAttribute("class", (mnu + idx));
		text = document.createTextNode(menus[id].title);
		liele.appendChild(text);
		liele.setAttribute("onclick", menus[id].action);
		uliste.appendChild(liele);
	}

}

function menuUp($par1, $par2, $par3) {
	//$par1,$par2: id, $par3 = class
	$par1.click(function () {
		$par3.fadeOut("slow");
		$par1.hide();
		$par2.show();
	});
}

function menuDown($par1, $par2, $par3) {
	//$par1,$par2: id, $par3 = class
	$par1.click(function () {
		$par3.fadeIn("slow");
		$par1.hide();
		$par2.show();
	});

}



