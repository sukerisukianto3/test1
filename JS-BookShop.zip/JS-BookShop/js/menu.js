"use strict";

var menus = [];
const btnu = "btnu";
const btnd = "btnd";
const mnu = "mn";

menus.push(new menu("Stammdaten", 0, [new menu("Buch", 0, [], "inputBook()"), new menu("Author", 0), new menu("Verlag", 0)]));
menus.push(new menu("Anzeigen", 0, [new menu("Buch-List", 0, [], "listBooks()"), new menu("Author-List", 0), new menu("Verlag-List", 0)]));

function menu(titel = "Default", sort = 0, children = [], action = "") {

	var titel, sort, children, action;

	this.titel = titel;
	this.sort = sort;
	this.children = children;
	this.action = action;

}

function displayAllMenus() {
	var nav = document.getElementById("navigation");
	var uliste;
	var head;
	var id = 0;
	var text = "";
	var children;
	var btn;
	var img;
	var btntx1, btntx2;

	for (id = 0; id < menus.length; id++) {
		text = document.createTextNode(menus[id].titel);
		head = document.createElement("h3");
		head.appendChild(text);
		nav.appendChild(head);
		uliste = document.createElement("ul");
		uliste.setAttribute("id", "ul" + id);
		// ====
		img = document.createElement("img");
		img.setAttribute("src", "img/up-arrow1.png");
		btn = document.createElement("button");
		btntx1 = btnu + (id + 1);
		btn.setAttribute("id", btntx1);
		btn.appendChild(img);
		uliste.appendChild(btn);
		//=======
		img = document.createElement("img");
		img.setAttribute("src", "img/down-arrow1.png");
		btn = document.createElement("button");
		btntx2 = btnd + (id + 1);
		btn.setAttribute("id", btntx2);
		btn.setAttribute("hidden", "hidden");
		btn.appendChild(img);
		uliste.append(btn);

		//===============================



		displayMenu(menus[id].children, uliste, id);


		nav.appendChild(uliste);
		//=========
		//add function up and down
		menuUp($("#" + btntx1), $("#" + btntx2), $("." + mnu + id));
		menuDown($("#" + btntx2), $("#" + btntx1), $("." + mnu + id));
		//=======================

	}


}

function displayMenu(menus, uliste, idx) {

	var id;
	var liele;
	var text;
	
	for (id = 0; id < menus.length; id++) {
		liele = document.createElement("li");
		liele.setAttribute("class", (mnu + idx));
		text = document.createTextNode(menus[id].titel);
		liele.appendChild(text);
		liele.setAttribute("onclick", menus[id].action);
		uliste.appendChild(liele);
	}

}

function menuUp($par1, $par2, $par3) {
	//$par1,$par2: id, $par3 = class
	$par1.click(function () {
		$par3.fadeOut("slow");
		$par1.hide();
		$par2.show();
	});
}

function menuDown($par1, $par2, $par3) {
	//$par1,$par2: id, $par3 = class
	$par1.click(function () {
		$par3.fadeIn("slow");
		$par1.hide();
		$par2.show();
	});

}



