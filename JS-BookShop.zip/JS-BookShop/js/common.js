function setContentBody(ele) {

    /*var content = document.getElementById("content");
    var child = content.firstChild;
    content.replaceChild(ele, child);*/
	var content = document.getElementById("contentBody");
	if (content.childElementCount> 0) {
		content.removeChild(content.childNodes[0]);  
	}
    content.appendChild(ele);
}


function createTableBody(id,cls="") {
    var tbody = document.createElement("tbody");
    tbody.setAttribute("id",id);
    if (cls != "") {
        tbody.setAttribute("class",cls);
    }
    return tbody;
}

function createTHTag(txt,colsp,cls="") {
    var th = document.createElement("th");
    var text = document.createTextNode(txt);
    th.appendChild(text);
    th.setAttribute("colspan",colsp);
    if (cls != "") {
        th.setAttribute("class",cls);
    }
    return th;
}

function createTDText(txt,cls="") {
    var td = document.createElement("td");
    var text = document.createTextNode(txt);
    td.appendChild(text);
    if (cls != "") {
        td.setAttribute("class",cls);
    }
    return td;
}

function createTDTag(tag, id,val) {
    var inp, td;
    inp = document.createElement(tag);
    inp.setAttribute("id", id);
    inp.setAttribute("value", val);
    td = document.createElement("td");
    td.appendChild(inp);
    return td;
}
function createTDButton(btn, id, titel, act) {
    var btn, td, text;
    btn = document.createElement(btn);
    btn.setAttribute("id", id);
    btn.setAttribute("onclick", act);
    text = document.createTextNode(titel);
    btn.appendChild(text);
    td = document.createElement("td");
    td.appendChild(btn);
    return td;
}

function searchInTableTR($par1, $par2) {
	//$par1 = "#myInput"
    //TR ="#myTable tr"
    $(document).ready(function() {
 $par1.on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $par2.filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
}
	