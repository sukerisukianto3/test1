"use strict";


function showAuthor(str){
    {
        var xhttp, opt;
        var idx, author_list;


        if (str.length == 0) 
        { 
          return;
        }
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() 
        {
          if (this.readyState == 4 && this.status == 200) 
          {
            //var option = document.createElement('option');
            var arr = this.responseText.split(";");
            author_list = $("#author_list");
            author_list.empty();
            for(idx=0; idx < arr.length; idx++) {
              opt = document.createElement('option');
              opt.value = arr[idx];
              author_list.append(opt);
            }
           
          }
        };
        xhttp.open("GET", "php/getauthor.php?q="+str, true);
        xhttp.send();   
      }
}