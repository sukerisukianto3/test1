"use strict";

const listTable = "listTable";
const inputArg = "inputArg";

var books = [];

function book(title = "Titel", desc = "desc", author = "author", year = 1900, price = 0.0, publisher = "verlag",
    isbn = "isbn", quantity = 0, language = "Deutsch") {
    var titel, desc, author, year, price, publisher, isbn, quantity, language;

    this.title = title;
    this.author = author;
    this.isbn = isbn;
    this.language = language;
    this.price = price;
    this.year = year;
    this.quantity = quantity;
    this.publisher = publisher;
    this.desc = desc;


}

function loadData() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            parseToObjects(this);
        }
    };
    xhttp.open("GET", "data/book_catalog.txt", true);
    xhttp.send();
}
function parseToObjects(json) {

    var jsonTxt = json.responseText;

    books = JSON.parse(jsonTxt);
}

function inputBook() {
    var tab, th, tr, td, text, inp, content;
    tab = document.createElement("table");
    tab.appendChild(createTHTag("Input Buch", 2));
    //------------------Titel-------------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Titel"));
    tr.appendChild(createTDTag("input", "title", "Buch Titel"));
    tab.appendChild(tr);
    //-------------------------------------------

    //--------------------Author--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Verfasser"));
    tr.appendChild(createTDTag("input", "author", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------isbn--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("ISBN"));
    tr.appendChild(createTDTag("input", "isbn", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Publisher--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Verlag"));
    tr.appendChild(createTDTag("input", "publisher", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Language--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Sprache"));
    tr.appendChild(createTDTag("input", "language", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Year--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Jahr"));
    tr.appendChild(createTDTag("input", "year", ""));
    tab.appendChild(tr);
    //-------------------------------------------    
    //--------------------Price--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Preis"));
    tr.appendChild(createTDTag("input", "price", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Anzahl--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Anzahl"));
    tr.appendChild(createTDTag("input", "quantity", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Desc--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Beschreibung"));
    tr.appendChild(createTDTag("textarea", "desc", "Buch Beschreibung"));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Button--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDButton("button", "save", "Speichern", "bookSave()"));
    tab.appendChild(tr);
    //-------------------------------------------

    setContentBody(tab);


}



function bookSave() {


    var titel = document.getElementById("title").value;
    var desc = document.getElementById("desc").value;
    var author = document.getElementById("author").value;
    var year = document.getElementById("year").value;
    var publisher = document.getElementById("publisher").value;
    var price = document.getElementById("price").value;
    var isbn = document.getElementById("isbn").value;
    var quantity = document.getElementById("quantity").value;
    var language = document.getElementById("language").value;


    //create buch
    var currbook = new book(titel, desc, author, year, price, publisher, isbn, quantity, language);
    books.push(currbook);
    //save to server
    transferToServer()

    inputBook();
}

function transferToServer() {
    // Object -> JSON (string)
    var bookStr = JSON.stringify(books);

    var request = new XMLHttpRequest();
    request.open("POST", "php/save.php", true);
    request.setRequestHeader("Content-type", "application/json");
    request.send(bookStr);
}

function listBooks() {

    var table = document.createElement("table");
    var tr, td, ix, img, txt;
    var tbody;

    table.setAttribute("class", "tab1");
    table.appendChild(createTHTag("Titel", 1, "tab1th"));
    table.appendChild(createTHTag("Author", 1, "tab1th"));
    table.appendChild(createTHTag("Jahr", 1, "tab1th"));
    table.appendChild(createTHTag("Preis", 1, "tab1th"));
    table.appendChild(createTHTag("   ", 1, "tab1th"));
    tbody = createTableBody(listTable);
    table.appendChild(tbody);
    for (ix = 0; ix < books.length; ix++) {
        tr = document.createElement("tr");
        tr.appendChild(createTDText(books[ix].title, "tab1td"));
        tr.appendChild(createTDText(books[ix].author, "tab1td"));
        tr.appendChild(createTDText(books[ix].year, "tab1td"));
        tr.appendChild(createTDText(books[ix].price, "tab1td"));
        //action
        td = createTDText("", "tab1td");
        img = document.createElement("img");
        img.setAttribute("src", "img/cart1.png");
        img.setAttribute("alt", "Zum Warenkorb");
        txt = "toShopingCart(" + "'" + books[ix].title + "'," + books[ix].price + ",1)";
        img.setAttribute("onclick", txt);
        td.appendChild(img);
        tr.appendChild(td);
        tbody.appendChild(tr);

    }

    setContentBody(table);

    searchInBookList();

}
function searchInBookList() {

    var img =$("<img></img>");
    var inputEle = $("<input></input>");
    inputEle.attr("id", inputArg);
    inputEle.attr("type", "text");
    inputEle.attr("placeholder", "Suchen...");
    var place = $("#contentHeader");
    place.empty();
   // place.append($("<br>"));
    img.attr("src","img/loupe.png");
    img.attr("width","17");
    img.attr("height","17");
    place.append(img);
    place.append(inputEle);
    //place.append($("<br>"));
    //place.append($("<br>"));


    searchInTableTR($("#"+inputArg), $("#"+listTable+" tr"));


}

