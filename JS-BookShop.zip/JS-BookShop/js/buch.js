"use strict";

const listTable = "listTable";
const inputArg = "inputArg";

// placeholder of books
var books = [];

// pointer to current element of books
var currIndex;

function book(title = "Titel", desc = "desc", author = "author", year = 1900, price = 0.0, publisher = "verlag",
    isbn = "isbn", quantity = 0, language = "Deutsch") {
    var titel, desc, author, year, price, publisher, isbn, quantity, language;

    this.title = title;
    this.author = author;
    this.isbn = isbn;
    this.language = language;
    this.price = price;
    this.year = year;
    this.quantity = quantity;
    this.publisher = publisher;
    this.desc = desc;


}


function parseToObjectsBook(json) {

    var jsonTxt = json.responseText;

    books = JSON.parse(jsonTxt);
}

/**
 * prepare the components to input a book
 */
function inputBook() {
    var tab, th, tr, td, text, inp, inp2, content, datalist;

    //clean output area
    contentEmpty();
    //set current Index to undefined
    currIndex = -1;

    tab = document.createElement("table");
    tab.appendChild(createTHTag("Input Buch", 2));
    //------------------Titel-------------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Titel"));
    tr.appendChild(createTDTag("input", "title", "Buch Titel"));
    tab.appendChild(tr);
    //-------------------------------------------

    //--------------------Author--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Verfasser"));
    td = createTDTag("input", "author", "");


    inp = document.createElement("input");
    inp.setAttribute("id", "author");
    inp.setAttribute("value", "");
    //get author
    inp.setAttribute("onKeyup", "showAuthor(this.value)");
    inp.setAttribute("list", "author_list");
    td = document.createElement("td");
    //datalist -- suggestion
    datalist = document.createElement("datalist");
    datalist.setAttribute("id", "author_list");

    td.appendChild(inp);
    td.appendChild(datalist);

    //td.setAttribute("onKeyup","showAuthor(this.value)");
    tr.appendChild(td);
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------isbn--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("ISBN"));
    tr.appendChild(createTDTag("input", "isbn", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Publisher--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Verlag"));
    tr.appendChild(createTDTag("input", "publisher", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Language--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Sprache"));
    tr.appendChild(createTDTag("input", "language", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Year--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Jahr"));
    tr.appendChild(createTDTag("input", "year", ""));
    tab.appendChild(tr);
    //-------------------------------------------    
    //--------------------Price--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Preis"));
    tr.appendChild(createTDTag("input", "price", ""));
    tr.append(createTDText("\u20AC"));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Anzahl--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Anzahl"));
    tr.appendChild(createTDTag("input", "quantity", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Desc--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Beschreibung"));
    tr.appendChild(createTDTag("textarea", "desc", "Buch Beschreibung"));
    tab.appendChild(tr);

    //display input menu
    setContentBody(tab);

    //-------------------------------------------
    //--------------------Button--------------------


    tab = document.createElement("table");
    tr = document.createElement("tr");
    //Neues
    tr.appendChild(createTDButton("neu", "Neu", "inputBook()"));
    //save
    tr.appendChild(createTDButton("save", "Speichern", "bookSave()"));
    //delete
    tr.appendChild(createTDButton("delete", "Delete", "bookDelete()"));
    //<
    tr.appendChild(createTDButton("back", "<", "bookBackward()"));
    //>
    tr.appendChild(createTDButton("forward", ">", "bookForward()"));
    tab.appendChild(tr);

    setContentFooter(tab);

    //-------------------------------------------


}


/**
 * save a book
 */
function bookSave() {

    var currBook;

    var titel = document.getElementById("title").value;
    var desc = document.getElementById("desc").value;
    var author = document.getElementById("author").value;
    var year = document.getElementById("year").value;
    var publisher = document.getElementById("publisher").value;
    var price = document.getElementById("price").value;
    var isbn = document.getElementById("isbn").value;
    var quantity = document.getElementById("quantity").value;
    var language = document.getElementById("language").value;


    //currBook = getABook(titel, author);
    if (currIndex == -1) {
        //create new Book
        currBook = new book(titel, desc, author, year, price, publisher, isbn, quantity, language);
        books.push(currBook);
        inputBook();
    } else {
        //update the book
        books[currIndex].title = titel;
        books[currIndex].author = author;
        books[currIndex].isbn = isbn;
        books[currIndex].language = language;
        books[currIndex].price = price;
        books[currIndex].year = year;
        books[currIndex].quantity = quantity;
        books[currIndex].publisher = publisher;
        books[currIndex].desc = desc;
    }

    //save to server
    transferToServer(books, "../data/book_catalog.txt");


}


/**
 * List all the books
 */
function listBooks() {

    var table = document.createElement("table");
    var tr, td, ix, img, txt;
    var tbody;

    //clean output scope
    contentEmpty();

    table.setAttribute("class", "tabelsc");
    table.appendChild(createTHTag("Titel", 1, "thsc"));
    table.appendChild(createTHTag("Author", 1, "thsc"));
    table.appendChild(createTHTag("Jahr", 1, "thsc"));
    table.appendChild(createTHTag("Preis(\u20AC)", 1, "thsc"));
    table.appendChild(createTHTag("   ", 1, "thsc"));
    tbody = createTableBody(listTable);
    table.appendChild(tbody);
    for (ix = 0; ix < books.length; ix++) {
        tr = document.createElement("tr");
        tr.setAttribute("class", "trsc");
        td = createTDText(books[ix].title, "tdsc");
        td.setAttribute("title", books[ix].desc);
        tr.appendChild(td);
        tr.appendChild(createTDText(books[ix].author, "tdsc"));
        tr.appendChild(createTDText(books[ix].year, "tdsc"));
        tr.appendChild(createTDText(books[ix].price, "tdsc"));
        //action
        td = createTDText("", "tdsc");
        img = document.createElement("img");
        img.setAttribute("src", "img/cart1.png");
        img.setAttribute("alt", "Zum Warenkorb");
        txt = "toShopingCart(" + "'" + books[ix].title + "','" + books[ix].price + "',1)";
        img.setAttribute("onclick", txt);
        td.appendChild(img);
        tr.appendChild(td);
        tbody.appendChild(tr);

    }

    //display list of books
    setContentBody(table);

    //set searching menu
    searchInBookList();

}
function searchInBookList() {

    var img = $("<img></img>");
    var inputEle = $("<input></input>");
    inputEle.attr("id", inputArg);
    inputEle.attr("type", "text");
    inputEle.attr("placeholder", "Suchen...");
    var place = $("#contentHeader");
    place.empty();

    img.attr("src", "img/loupe.png");
    img.attr("width", "17");
    img.attr("height", "17");
    place.append(img);
    place.append(inputEle);



    searchInTableTR($("#" + inputArg), $("#" + listTable + " tr"));

}



function bookBackward() {

    if (currIndex == -1) {
        currIndex = books.length - 1;
    } else {
        if (currIndex != 0) {
            currIndex -= 1;
        }
    }
    showBook(currIndex);
}

function bookForward() {
    if (currIndex == (books.length - 1)) {
        currIndex = -1;
    } else {
        currIndex += 1;
    }

    showBook(currIndex);
}
/**
 * show the selected book
 * @param  {number} currIndex current index ponts to a book from books<array>
 */
function showBook(currIndex) {

    if (currIndex != -1) {
        var currBook = books[currIndex];

        $("#title").val(currBook.title);
        $("#desc").val(currBook.desc);
        $("#author").val(currBook.author);
        $("#year").val(currBook.year);
        $("#publisher").val(currBook.publisher);
        $("#price").val(currBook.price);
        $("#isbn").val(currBook.isbn);
        $("#quantity").val(currBook.quantity);
        $("#language").val(currBook.language);
    } else {
        emptyBookInput();
    }
}

function emptyBookInput() {
    $("#title").val("Buch Titel");
    $("#desc").val("");
    $("#author").val("");
    $("#year").val("");
    $("#publisher").val("");
    $("#price").val("");
    $("#isbn").val("");
    $("#quantity").val("");
    $("#language").val("");
}

function bookDelete() {

    if (currIndex != -1) {
        books.splice(currIndex, 1);
        currIndex -= 1;
        bookForward();
        //save to server
        transferToServer(books, "../data/book_catalog.txt");
    }
}



