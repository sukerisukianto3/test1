"use strict";

var customers = [];

function parseToObjectsCustomer(json) {

    var jsonTxt = json.responseText;

    customers = JSON.parse(jsonTxt);
}



function csShowCustomerAddress(name) {


    var para;
    var currCustomer,currAddress;

    currCustomer = getAcustomer(name);
    if (currCustomer != null) {
        currAddress = currCustomer.address[0];
        para =$("#iaddress");
        para.empty();
        para.append("Lieferadresse:");
        para.append($("<br>"));
        para.append(currAddress.street);
        para.append($("<br>"));
        para.append(currAddress.zipcode);
    }
   //enabled Btn kaufen
   var btnbKaufen = $("#kaufen");
    btnbKaufen.prop("disabled",false);


}

function getAcustomer(name){

    for (let key in customers){
        if (customers[key].name.toLowerCase() == name.toLowerCase()) {
            return customers[key];
        }
    }
    return null;
}