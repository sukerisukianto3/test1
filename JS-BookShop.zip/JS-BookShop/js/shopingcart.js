"use strict";

var carts=[];

function cart(title,quantity,price) {
	
	var title;
	var quantity;
	var price;
	var totalPrice;
	
	this.title =title;
	this.quantity = quantity;
	this.price=price;
	this.totalPrice = ()=>{return  this.quantity * + this.price;}
		
}
function toShopingCart(title,price,quantity) {
	carts.push(new cart(title,price,quantity));
}


function showShopingCart() {
	alert("content of shopingvart");
}