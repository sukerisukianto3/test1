function setContentChild(ele) {

    var content = document.getElementById("content");
    var child = content.firstChild;
    content.replaceChild(ele, child);
}

function createTHTag(txt,colsp,cls="") {
    var th = document.createElement("th");
    var text = document.createTextNode(txt);
    th.appendChild(text);
    th.setAttribute("colspan",colsp);
    if (cls != "") {
        th.setAttribute("class",cls);
    }
    return th;
}

function createTDText(txt,cls="") {
    var td = document.createElement("td");
    var text = document.createTextNode(txt);
    td.appendChild(text);
    if (cls != "") {
        td.setAttribute("class",cls);
    }
    return td;
}

function createTDTag(tag, id,val) {
    var inp, td;
    inp = document.createElement(tag);
    inp.setAttribute("id", id);
    inp.setAttribute("value", val);
    td = document.createElement("td");
    td.appendChild(inp);
    return td;
}
function createTDButton(btn, id, titel, act) {
    var btn, td, text;
    btn = document.createElement(btn);
    btn.setAttribute("id", id);
    btn.setAttribute("onclick", act);
    text = document.createTextNode(titel);
    btn.appendChild(text);
    td = document.createElement("td");
    td.appendChild(btn);
    return td;
}