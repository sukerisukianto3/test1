"use strict";

var books = [];

function book(titel = "Default", desc = "", author = "", year = 1900, price = 0.0, publisher = "",
                isbn="",quantity=0,language="Deutsch") {
    var titel, desc, author, year, price, publisher,isbn,quantity,language;

    this.titel = titel;
    this.desc = desc;
    this.author = author;
    this.year = year;
    this.price = price;
    this.publisher = publisher;
    this.isbn = isbn;
    this.quantity=quantity;
    this.language = language;

}

function loadData() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            myFunction(this);
        }
    };
    xhttp.open("GET", "book_catalog.xml", true);
    xhttp.send();
}
function myFunction(xml) {
    var i;
    var titel, author, year, isbn, language, price, quantity, desc, publisher;
    var currBook;
    var xmlDoc = xml.responseXML;

    var x = xmlDoc.getElementsByTagName("BOOK");
    for (i = 0; i < x.length; i++) {
        titel = x[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue;
        author = x[i].getElementsByTagName("AUTHOR")[0].childNodes[0].nodeValue;
        year = x[i].getElementsByTagName("YEAR")[0].childNodes[0].nodeValue;
        isbn = x[i].getElementsByTagName("ISBN")[0].childNodes[0].nodeValue;
        language = x[i].getElementsByTagName("LANGUAGE")[0].childNodes[0].nodeValue;
        price = x[i].getElementsByTagName("PRICE")[0].childNodes[0].nodeValue;
        quantity = x[i].getElementsByTagName("QUANTITY")[0].childNodes[0].nodeValue;
        publisher = x[i].getElementsByTagName("PUBLISHER")[0].childNodes[0].nodeValue;
        desc = x[i].getElementsByTagName("DESC")[0].childNodes[0].nodeValue;
        currBook = new book(titel,desc,author,year,price,publisher,isbn,quantity,language);
        books.push(currBook);
    }
    
}

function inputBook() {
    var tab, th, tr, td, text, inp, content;
    tab = document.createElement("table");
    tab.appendChild(createTHTag("Input Buch", 2));
    //------------------Titel-------------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Titel"));
    tr.appendChild(createTDTag("input", "titel", "Buch Titel"));
    tab.appendChild(tr);
    //-------------------------------------------
    
    //--------------------Author--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Verfasser"));
    tr.appendChild(createTDTag("input", "author", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Desc--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("ISBN"));
    tr.appendChild(createTDTag("input", "isbn", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Publisher--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Verlag"));
    tr.appendChild(createTDTag("input", "publisher", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Year--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Jahr"));
    tr.appendChild(createTDTag("input", "year", ""));
    tab.appendChild(tr);
    //-------------------------------------------    
    //--------------------Price--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Preis"));
    tr.appendChild(createTDTag("input", "price", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Desc--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Anzahl"));
    tr.appendChild(createTDTag("text", "quantity", ""));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Desc--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDText("Beschreibung"));
    tr.appendChild(createTDTag("textarea", "desc", "Buch Beschreibung"));
    tab.appendChild(tr);
    //-------------------------------------------
    //--------------------Button--------------------
    tr = document.createElement("tr");
    tr.appendChild(createTDButton("button", "save", "Speichern", "bookSave()"));
    tab.appendChild(tr);
    //-------------------------------------------

    setContentChild(tab);


}



function bookSave() {


    var titel = document.getElementById("titel").value;
    var desc = document.getElementById("desc").value;
    var author = document.getElementById("author").value;
    var year = document.getElementById("year").value;
    var publisher = document.getElementById("publisher").value;
    var price = document.getElementById("price").value;

    //create buch
    var currbook = new book(titel, desc, author, year, price, publisher);
    books.push(currbook);
    //alert("saving book:"+titel);
    inputBook();
}

function listBooks() {

    var table = document.createElement("table");
    var tr;
    var ix;
    table.setAttribute("class", "tab1");

    table.appendChild(createTHTag("Titel", 1, "tab1th"));
    table.appendChild(createTHTag("Author", 1, "tab1th"));
    table.appendChild(createTHTag("Jahr", 1, "tab1th"));
    table.appendChild(createTHTag("Preis", 1, "tab1th"));
    table.appendChild(createTHTag("   ", 1, "tab1th"));
    for (ix =0; ix <books.length;ix++) {
        tr = document.createElement("tr");
        tr.appendChild(createTDText(books[ix].titel,"tab1td"));
        tr.appendChild(createTDText(books[ix].author,"tab1td"));
        tr.appendChild(createTDText(books[ix].year,"tab1td"));
        tr.appendChild(createTDText(books[ix].price,"tab1td"));
        table.appendChild(tr);

    }

    setContentChild(table);

}

