"use strict";
let a = 9;
let b = 8;

switch (true) {
  case a <= 10 && b <= 10:
    console.log('all lte 10');
    break;
  case a > 10 && b > 10:
    console.log('all gt 10');
    break;
  default:
    console.log('mixed lte gt 10');
}